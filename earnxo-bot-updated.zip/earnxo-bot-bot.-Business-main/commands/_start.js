/*CMD
  command: /start
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

function onTouchOwnLink() {
  Bot.sendMessage("⚠️ This is your own referral link!");
}

function onAlreadyAttracted() {
  // already registered, show menu
}

function onAttracted(byUser) {
  // With force-join ON, the referral is paid only after the new user joins the channel
  // (stops fake/empty-account referrals). Otherwise pay immediately.
  if (Libs.JoinLib.enabled()) {
    User.setProp("referrer_pending", byUser.telegramid);
  } else {
    Libs.LevelLib.creditReferral(byUser.telegramid);
  }
}

RefLib.track({
  onTouchOwnLink: onTouchOwnLink,
  onAlreadyAttracted: onAlreadyAttracted,
  onAttracted: onAttracted
});

if (chat.just_created) {
  User.setProp("joined_at", Date.now(), "integer");
  User.setProp("balance", 0, "float");
}

Bot.sendMessage(
  "🚀 *Welcome to NxT Giveaway Bot!*\n\n" +
  "💰 Earn USDT by inviting friends\n" +
  "🎁 Redeem promo codes for instant balance\n" +
  "💸 Withdraw to your BEP-20 wallet\n\n" +
  "Choose an option below 👇"
);

if (Libs.JoinLib.guard()) {
  Bot.runCommand("/menu");
}
