/*CMD
  command: /addtask
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (String(user.telegramid) !== "8373846582") { Bot.sendMessage("⛔ Access Denied."); return; }

// /addtask Title | https://t.me/channel | 0.05 | join     (type: join or link)
let p = String(params || "").split("|").map(function (s) { return s.trim(); });
if (p.length < 4 || !p[0] || !p[1]) {
  Bot.sendMessage(
    "📝 *Add Task*\n\nFormat:\n`/addtask Title | link | reward | type`\n\n" +
    "type = `join` (auto-verified, public channel) or `link`\n\n" +
    "Example:\n`/addtask Join our partner | https://t.me/partner | 0.05 | join`"
  );
  return;
}

let reward = parseFloat(p[2]);
let type = p[3].toLowerCase() === "join" ? "join" : "link";
if (isNaN(reward) || reward <= 0) { Bot.sendMessage("❌ Invalid reward."); return; }

let tasks = JSON.parse(Bot.getProp("tasks", "[]"));
let id = parseInt(Bot.getProp("task_seq", 0)) + 1;
Bot.setProp("task_seq", id, "integer");
tasks.push({ id: id, title: p[0], url: p[1], reward: reward, type: type });
Bot.setProp("tasks", JSON.stringify(tasks));

Bot.sendMessage("✅ Task #" + id + " added: *" + p[0] + "* (+$" + reward + ", " + type + ")\n\nDelete with `/deltask " + id + "`");
