/*CMD
  command: /on_task_result
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let id = String(User.getProp("task_pending", ""));
User.setProp("task_pending", "");
let tasks = JSON.parse(Bot.getProp("tasks", "[]"));
let t = tasks.filter(function (x) { return String(x.id) === id; })[0];
if (!t) return;
if (User.getProp("task_done_" + t.id, "0") === "1") return;

if (Libs.JoinLib.isMember(options.result)) {
  Libs.LevelLib.addBalance(user.telegramid, parseFloat(t.reward));
  User.setProp("task_done_" + t.id, "1");
  Bot.sendMessage("✅ *Task Completed!*\n\n💰 +$" + t.reward + " USDT");
} else {
  Bot.sendMessage("❌ We couldn't see you in the channel. Join first, then tap Completed again.");
}
