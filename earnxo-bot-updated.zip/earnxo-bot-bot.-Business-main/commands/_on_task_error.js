/*CMD
  command: /on_task_error
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

Bot.sendMessage({
  chat_id: Bot.getProp("admin_chat_id", "8373846582"),
  text: "⚠️ A join-task could not be verified. Make sure the bot is ADMIN in that task's channel."
});
Bot.sendMessage("⚠️ Could not verify right now. Try again later.");
