/*CMD
  command: /check_join
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (Libs.JoinLib.isVerified()) { Bot.runCommand("/menu"); return; }
Libs.JoinLib.check();
