/*CMD
  command: 🎁 Daily Bonus
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (!Libs.JoinLib.guard()) return;

const DAY = 24 * 60 * 60 * 1000;
let now = Date.now();
let last = parseInt(User.getProp("daily_last", 0)) || 0;

if (now - last < DAY) {
  let left = DAY - (now - last);
  let h = Math.floor(left / 3600000);
  let m = Math.floor((left % 3600000) / 60000);
  Bot.sendMessage("⏳ Already claimed today.\n\nCome back in *" + h + "h " + m + "m*");
  return;
}

let streak = parseInt(User.getProp("daily_streak", 0)) || 0;
streak = (now - last < 2 * DAY) ? streak + 1 : 1;

let base = parseFloat(Bot.getProp("daily_bonus", 0.02));
let step = Math.min(streak, 7) - 1;               // streak bonus caps at day 7
let bonus = Math.round((base + step * base * 0.25) * 10000) / 10000;

Libs.LevelLib.addBalance(user.telegramid, bonus);
User.setProp("daily_last", now, "integer");
User.setProp("daily_streak", streak, "integer");

Bot.sendMessage(
  "🎁 *Daily Bonus Claimed!*\n\n" +
  "💰 +$" + bonus + " USDT\n" +
  "🔥 Streak: *" + streak + " day(s)*\n" +
  "💵 Balance: *$" + parseFloat(User.getProp("balance", 0)).toFixed(2) + " USDT*\n\n" +
  "Come back tomorrow to keep your streak!"
);
