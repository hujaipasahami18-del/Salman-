/*CMD
  command: /deltask
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (String(user.telegramid) !== "8373846582") { Bot.sendMessage("⛔ Access Denied."); return; }

let tasks = JSON.parse(Bot.getProp("tasks", "[]"));
let id = String(params || "").trim();

if (!id) {
  if (tasks.length === 0) { Bot.sendMessage("No tasks yet. Use /addtask"); return; }
  Bot.sendMessage("📋 *Tasks*\n\n" + tasks.map(function (t) {
    return "#" + t.id + " — " + t.title + " ($" + t.reward + ", " + t.type + ")";
  }).join("\n") + "\n\nDelete: `/deltask ID`");
  return;
}

let left = tasks.filter(function (t) { return String(t.id) !== id; });
if (left.length === tasks.length) { Bot.sendMessage("❌ Task not found."); return; }
Bot.setProp("tasks", JSON.stringify(left));
Bot.sendMessage("🗑 Task #" + id + " deleted.");
