/*CMD
  command: 📋 Tasks
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (!Libs.JoinLib.guard()) return;

let tasks = JSON.parse(Bot.getProp("tasks", "[]"));
let buttons = [];

for (let i = 0; i < tasks.length; i++) {
  let t = tasks[i];
  if (User.getProp("task_done_" + t.id, "0") === "1") continue;
  buttons.push([{ title: "▶️ " + t.title + " (+$" + t.reward + ")", command: "/task_open " + t.id }]);
}

if (buttons.length === 0) {
  Bot.sendMessage("📋 *Tasks*\n\n✅ No new tasks right now. Check back soon!");
  return;
}

Bot.sendInlineKeyboard(buttons, "📋 *Available Tasks*\n\nComplete tasks to earn USDT 👇");
