/*CMD
  command: /task_done
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (!Libs.JoinLib.guard()) return;

let id = String(params).trim();
let tasks = JSON.parse(Bot.getProp("tasks", "[]"));
let t = tasks.filter(function (x) { return String(x.id) === id; })[0];

if (!t) { Bot.sendMessage("❌ Task not found."); return; }
if (User.getProp("task_done_" + t.id, "0") === "1") { Bot.sendMessage("✅ You already completed this task."); return; }

let started = parseInt(User.getProp("task_start_" + t.id, 0)) || 0;
let minSec = parseInt(Bot.getProp("min_task_seconds", 15));

if (!started) { Bot.sendMessage("⚠️ Open the task first."); return; }

if ((Date.now() - started) < minSec * 1000) {
  Bot.sendMessage("⏳ Please actually complete the task first, then tap Completed.");
  return;
}

if (t.type === "join") {
  let m = String(t.url).match(/t\.me\/([A-Za-z0-9_]{4,})\/?$/);
  if (!m) { Bot.sendMessage("⚠️ This task can't be auto-verified. Contact support."); return; }
  User.setProp("task_pending", t.id);
  Api.getChatMember({
    chat_id: "@" + m[1],
    user_id: user.telegramid,
    on_result: "/on_task_result",
    on_error: "/on_task_error"
  });
  return;
}

// link tasks are honor-based (Telegram can't verify external sites)
Libs.LevelLib.addBalance(user.telegramid, parseFloat(t.reward));
User.setProp("task_done_" + t.id, "1");
Bot.sendMessage("✅ *Task Completed!*\n\n💰 +$" + t.reward + " USDT");
