/*CMD
  command: /on_join_error
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

// Usually: bot is not admin of the channel, or the channel link is not a public @username link.
let admin = Bot.getProp("admin_chat_id", "8373846582");
Bot.sendMessage({
  chat_id: admin,
  text: "⚠️ Force-join check failed.\nMake sure the bot is an ADMIN of the channel and channel_link is a public https://t.me/username link."
});
Bot.sendMessage("⚠️ Could not verify right now. Please try again in a moment.");
