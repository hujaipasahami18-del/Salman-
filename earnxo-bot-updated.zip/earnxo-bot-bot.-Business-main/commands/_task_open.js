/*CMD
  command: /task_open
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (!Libs.JoinLib.guard()) return;

let id = String(params).trim();
let tasks = JSON.parse(Bot.getProp("tasks", "[]"));
let t = tasks.filter(function (x) { return String(x.id) === id; })[0];

if (!t) { Bot.sendMessage("❌ Task not found."); return; }
if (User.getProp("task_done_" + t.id, "0") === "1") { Bot.sendMessage("✅ You already completed this task."); return; }

User.setProp("task_start_" + t.id, Date.now(), "integer");

let how = (t.type === "join")
  ? "Join the channel, then tap *Completed* — we verify automatically."
  : "Open the link, finish the task, then tap *Completed*.";

Bot.sendInlineKeyboard([
  [{ title: "🔗 Open Task", url: t.url }],
  [{ title: "✅ Completed", command: "/task_done " + t.id }]
],
  "📋 *" + t.title + "*\n\n💰 Reward: *$" + t.reward + " USDT*\n\n" + how
);
