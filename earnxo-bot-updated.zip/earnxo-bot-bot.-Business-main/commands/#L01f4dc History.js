/*CMD
  command: 📜 History
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

let list = Libs.LevelLib.readHistory(user.telegramid);

if (!list.length) {
  Bot.sendMessage("📜 *Withdrawal History*\n\nNo withdrawals yet.");
  return;
}

let icon = { pending: "⏳", approved: "✅", rejected: "❌" };
let msg = "📜 *Withdrawal History* (last " + list.length + ")\n\n";

for (let i = 0; i < list.length; i++) {
  let h = list[i];
  msg += (icon[h.status] || "•") + " *$" + parseFloat(h.amount).toFixed(2) + " USDT* — " + h.status +
         "\n📅 " + new Date(h.ts).toDateString();
  if (h.tx) msg += "\n🔗 TX: `" + h.tx + "`";
  msg += "\n\n";
}

Bot.sendMessage(msg);
