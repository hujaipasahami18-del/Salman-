/*CMD
  command: /on_join_result
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

if (Libs.JoinLib.isMember(options.result)) {
  User.setProp("join_verified", "1");
  Bot.sendMessage("✅ *Verified!* Welcome aboard 🎉");
  Libs.LevelLib.payPendingReferral();
  Bot.runCommand("/menu");
} else {
  Bot.sendMessage("❌ You have not joined the channel yet.");
  Libs.JoinLib.prompt();
}
