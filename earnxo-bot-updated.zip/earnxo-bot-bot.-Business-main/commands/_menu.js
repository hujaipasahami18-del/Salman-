/*CMD
  command: /menu
  help: 
  need_reply: false
  auto_retry_time: 
  folder: 

  <<ANSWER

  ANSWER

  <<KEYBOARD

  KEYBOARD
  aliases: 
  group: 
CMD*/

Bot.sendKeyboard(
  "💰 Balance, 👥 Invite Friends\n" +
  "🎁 Daily Bonus, 📋 Tasks\n" +
  "🎫 Promo Code, 💸 Withdraw\n" +
  "📜 History, 🏅 Levels\n" +
  "🚪 Channel Access, 🏆 Leaderboard\n" +
  "📊 My Stats, ❓ Help",
  "📌 Main Menu"
);
